/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package kasirsateayah2;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class koneksi {

    // Ganti dengan username, password, dan nama database yang sesuai
    private static final String URL = "jdbc:mysql://localhost:3306/db_sateayah";
    private static final String USER = "root"; // Username MySQL
    private static final String PASSWORD = ""; // Password MySQL
    
    private static Connection Connection = null;

    // Mengambil koneksi ke database
    public static Connection getConnection() {
        if (Connection == null) {
            try {
                try {
                    // Cek apakah koneksi berhasil
                    Class.forName("com.mysql.cj.jdbc.Driver");
                } catch (ClassNotFoundException ex) {
                    Logger.getLogger(koneksi.class.getName()).log(Level.SEVERE, null, ex);
                }
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            return conn;
        } catch (SQLException e) {
            System.out.println("Error koneksi: " + e.getMessage());
            return null;
            }
        }
        return Connection;
    }
}