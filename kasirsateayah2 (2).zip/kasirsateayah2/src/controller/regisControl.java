/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.sql.SQLException;

public class regisControl {
    private userDao userDAO;

    public regisControl() {
        userDAO = new userDao();
    }

    public boolean registerUser(String username, String password, String namaLengkap) {
        userModel newUser = new userModel();
        newUser.setUsername(username);
        newUser.setPassword(password); 
        newUser.setNamaLengkap(namaLengkap);

        try {
            userDAO.addUser(newUser);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}