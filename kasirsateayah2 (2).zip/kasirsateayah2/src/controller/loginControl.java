/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
import java.sql.SQLException;

/**
 *
 * @author acer
 */
public class loginControl {
    private userDao userDAO;

    public loginControl() {
        userDAO = new userDao();
    }

    public userModel login(String username, String password) {
        try {
            userModel user = userDAO.getUserByUsername(username);
            if (user != null && password.equals(user.getPassword())) {
                return user;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
